

$(document).ready(function(){
    console.log("h"+zidingyi_height*0.9)
$("#xuanze").slimScroll({
            height: zidingyi_height*0.8+'px'
        });

$("#zhanshi").slimScroll({
           height: zidingyi_height*0.8+'px'
        });
})
